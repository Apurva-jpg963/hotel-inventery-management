import os
import sys

# Add the project directory to the Python path
project_home = os.path.dirname(os.path.abspath(__file__))
if project_home not in sys.path:
    sys.path.insert(0, project_home)

# If a virtualenv is used, uncomment and update the following lines:
# activate_this = os.path.join(project_home, 'venv', 'Scripts', 'activate_this.py')
# with open(activate_this) as file_:
#     exec(file_.read(), dict(__file__=activate_this))

from app import app as application
